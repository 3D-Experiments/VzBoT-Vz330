## Please note the USB-C port is not needed when connected with ribbon cable (DSI)

<img width="814" alt="image" src="https://github.com/VzBoT3D/VzBoT-Vz330/assets/37383368/bfed3c4a-3ce8-460e-95ef-eff7785a9a27">


BOM:

- 4 x 6mm M3 bolts
- 1 x 25mm M4 bolts (for the hinge)
- 1 x M4 nut
- 2 x M4 8mm bolt (to bolt to frame)
- 2 M4 T-nuts
- Screen : https://s.click.aliexpress.com/e/_DDhO8jX
<img width="865" alt="image" src="https://github.com/VzBoT3D/VzBoT-Vz330/assets/37383368/26dc9b19-09a2-4260-acef-3741f632d32d">


<img width="892" alt="image" src="https://github.com/VzBoT3D/VzBoT-Vz330/assets/37383368/2c8cee4d-5e24-40d0-b2b0-ac777cb14546">

BOM Needed:

- 4 x M3 10mm  (To lock levers to latches)
- 4 x M3 8mmm (To bolt to front door panels)
-  4 x M3 heat inserts 

<img width="801" alt="image" src="https://user-images.githubusercontent.com/37383368/217716110-0b5833e2-fd71-4492-99b9-136f32e5640b.png">
<img width="874" alt="image" src="https://user-images.githubusercontent.com/37383368/217714155-cc7429ff-a772-4924-8275-b6845c8a893f.png">
<img width="885" alt="image" src="https://user-images.githubusercontent.com/37383368/217714064-7ea6cfaa-8a6a-46e8-8a4f-ce0758ad9d69.png">


